﻿namespace Backend.Entities.Customer.Dto
{
    public class CustomerDto
    {
        public string DisplayName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string CCCD { get; set; }
        public string Gender { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
    }
}
