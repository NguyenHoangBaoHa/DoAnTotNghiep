﻿namespace Backend.Entities.Account.Model
{
    public class LoginModel
    {
        public string Username { get; set; }
        public string Token { get; set; }
    }
}
