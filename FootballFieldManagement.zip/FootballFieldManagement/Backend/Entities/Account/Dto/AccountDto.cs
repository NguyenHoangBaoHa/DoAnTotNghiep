﻿namespace Backend.Entities.Account.Dto
{
    public class AccountDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
